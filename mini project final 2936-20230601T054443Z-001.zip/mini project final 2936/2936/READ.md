# Javascript Calculator

Simple Calculator Using Javascript

- You can also type using your keyboard :)

Made as an assignment while learning Javascript

Domo: https://muhammadovi.github.io/js-calculator
